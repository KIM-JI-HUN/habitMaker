import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'global_widget.dart';

class SelectPage extends StatelessWidget {
  const SelectPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              color: Colors.deepOrangeAccent,
              onPressed: () =>
                  Get.back(),
            ),
            title: const Text('자신의 MBTI를 선택하세요',
              style: TextStyle(
                  color: Colors.deepOrangeAccent,
                  fontWeight: FontWeight.bold
              ),

            ),
          ),
          body: SafeArea(
            child: Stack(
              children: [
                GridView.count(
                  crossAxisCount: 4,
                  crossAxisSpacing: 20,
                  mainAxisSpacing: 50,
                  padding: const EdgeInsets.all(20),
                  children: <Widget>[
                    OutlinedButton(
                      child: const Text('ENFJ',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'ENFJ 특징',
                                content: '자신이 믿는 사람이나 명분을 실망시키는 것보다 주인공을 괴롭히는 일은 거의 없습니다.',
                              onSucceed: () => {
                                Get.back(),
                                Get.toNamed('/enfj'),
                              }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('ENTJ',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'ENTJ 특징',
                                content: '때때로 이 모든 자신감과 의지가 너무 지나칠 수 있으며, 지휘관은 모든 논쟁에서 승리하기 위해 노력하고 자신의 비전을 혼자 힘으로 밀어붙일 수 있습니다.',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/entj'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('INFP',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'INFP 특징',
                                content: '그들은 삶에서 좋은 것을 나누고, 마땅히 해야 할 일에 공을 돌리고, 주변 사람들을 고양시키라는 부름을 받았습니다.',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/infp'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('INFJ',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'INFJ 특징',
                                content: '옹호자는 삶의 목적 의식을 갈망하며 미래에 대한 자신의 비전의 아름다움에 힘을 얻고 열정적입니다.',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/infj'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('ENFP',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'ENFP 특징',
                                content: '운동가는 협업에서 열정적이고 자발적이지만 장기적으로 규율을 유지하는데에는 어려움을 겪을수있습니다.',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/enfp'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('ENTP',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'ENTP 특징',
                                content: '토론자는 새로운 것, 특히 추상적인 개념을 배울 수 있는 좋은 기회를 거의 놓치지 않습니다.',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/entp'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('INTP',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'INTP 특징',
                                content: '논리학자는 자신의 지식과 아이디어를 공유하는 데 자부심을 느낍니다. ',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/intp'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('ISTP',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'ISTP 특징',
                                content: '장기 약속은 특히 Virtuosos에게 부담이 됩니다. 그들은 매일매일 일을 하는 것을 선호하고, 오랫동안 무언가에 갇힌 느낌은 완전히 억압적입니다.',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/istp'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('ESFP',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'ESFP 특징',
                                content: '엔터테이너는 경험할수있는 모든것을 경험하고자 하며 세부계획을 거의 세우지않습니다.',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/esfp'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('ESTP',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'ESTP 특징',
                                content: '기업가의 독창성은 언제 상황이 바뀌고 언제 변화해야하는지 알아차리는 지각력에 도움이 됩니다.',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/estp'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('ISFP',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'ISFP 특징',
                                content: '모험가는 작은 일을 격렬한 경쟁으로 확대하여 순간의 영광을 위한 장기적인 성공을 좌절시키고 패배했을 때 불행합니다.',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/isfp'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('ISFJ',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'ISFJ 특징',
                                content: '수비수는 다른 사람을 돕는 것을 진정으로 즐기며 지식, 관심 및 전문 지식을 필요로 하는 모든 사람과 기꺼이 공유합니다. ',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/isfj'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('ESFJ',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'ESFJ 특징',
                                content: '사회적 지위와 영향력에 대한 영사의 집착은 많은 결정에 영향을 미친다.',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/esfj'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('ESTJ',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'ESTJ 특징',
                                content: '경영진은 사실과 가장 효과적인 방법에 대해 생각하다보니 그들과 다른사람들의 감수성에 대해 생각하는것을 잊어버리기도 합니다.',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/estj'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('ISTJ',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'ISTJ 특징',
                                content: '스스로 책임을 져야 했기 때문에 물류 전문가는 실패에 대한 책임이 자신에게만 있다고 생각합니다.',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/istj'),
                                }
                            )
                        );
                      },
                    ),
                    OutlinedButton(
                      child: const Text('INTJ',style: TextStyle(color: Colors.deepOrangeAccent),),
                      onPressed: () {
                        Get.dialog(
                            GlobalWidgets.checkDialog(
                                title: 'INTJ 특징',
                                content: '기대를 무시하려는 그들의 노력으로 인해 다른 사람들과 고립되거나 단절된 느낌이 들 수 있습니다.',
                                onSucceed: () => {
                                  Get.back(),
                                  Get.toNamed('/intj'),
                                }
                            )
                        );
                      },
                    ),
                  ],
                ),
                Positioned(
                    bottom: 130,
                    left: 20,
                    right: 20,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.deepOrangeAccent
                      ),
                      child: const Text('MBTI 테스트'),
                      onPressed: () {
                        Get.toNamed('/page2');
                      },
                    ),
                )
              ],


            )
          ),
        ),
        onWillPop: () async {
          return true;
        }
    );
  }
}