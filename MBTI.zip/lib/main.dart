import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:mbti/Todo_page.dart';
import 'package:mbti/Select_page.dart';

import 'Login_page.dart';
import 'MBTIpage/enfj_page.dart';
import 'MBTIpage/enfp_page.dart';
import 'MBTIpage/entj_page.dart';
import 'MBTIpage/entp_page.dart';
import 'MBTIpage/esfj_page.dart';
import 'MBTIpage/esfp_page.dart';
import 'MBTIpage/estj_page.dart';
import 'MBTIpage/estp_page.dart';
import 'MBTIpage/infj_page.dart';
import 'MBTIpage/infp_page.dart';
import 'MBTIpage/intj_page.dart';
import 'MBTIpage/intp_page.dart';
import 'MBTIpage/isfj_page.dart';
import 'MBTIpage/isfp_page.dart';
import 'MBTIpage/istj_page.dart';
import 'MBTIpage/istp_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      routes: {
        '/' : (context) => const LoginPage(),
        '/page1' : (context) => const SelectPage(),
        '/istj' : (context) => const ISTJ(),
        '/isfj' : (context) => const ISFJ(),
        '/infj' : (context) => const INFJ(),
        '/intj' : (context) => const INTJ(),
        '/istp' : (context) => const ISTP(),
        '/isfp' : (context) => const ISFP(),
        '/infp' : (context) => const INFP(),
        '/intp' : (context) => const INTP(),
        '/estp' : (context) => const ESTP(),
        '/esfp' : (context) => const ESFP(),
        '/enfp' : (context) => const ENFP(),
        '/entp' : (context) => const ENTP(),
        '/estj' : (context) => const ESTJ(),
        '/esfj' : (context) => const ESFJ(),
        '/enfj' : (context) => const ENFJ(),
        '/entj' : (context) => const ENTJ(),
        '/page3' : (context) => TodoPage(),
      },
    );
  }
}

