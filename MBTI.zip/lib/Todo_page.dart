import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mbti/TodoController.dart';

import 'Todo.dart';

class TodoPage extends StatelessWidget {
  static final TodoController todoController = Get.find();

  late var index;

  TodoPage({this.index});
  @override
  Widget build(BuildContext context) {
    TextEditingController titleController = TextEditingController();
    TextEditingController contentController = TextEditingController();
    TextEditingController rewardController = TextEditingController();
    var title = '';
    var content = '';
    var reward = '';
    if(index != null) {
      title = todoController.todos[index].title;
      content = todoController.todos[index].content;
      reward = todoController.todos[index].reward;
    }
    titleController = TextEditingController(text: title);
    contentController = TextEditingController(text: content);
    rewardController = TextEditingController(text: reward);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.deepOrangeAccent,
          onPressed: () =>
              Get.back(),
        ),
        title: const Text('습관 만들기',
          style: TextStyle(
              color: Colors.deepOrangeAccent,
              fontWeight: FontWeight.bold
          ),

        ),
      ),
      body: SingleChildScrollView(
        //padding: const EdgeInsets.all(10),
        scrollDirection: Axis.vertical,
        child: Column(
          children: [
            Container(
              height: 100,
              margin: const EdgeInsets.all(10),
              child: TextField(
                autofocus: true,
                controller: titleController,
                decoration: const InputDecoration(
                  labelText: '제목',
                  labelStyle: TextStyle(color: Colors.deepOrangeAccent),
                  border: OutlineInputBorder(),
                ),
                style: const TextStyle(
                  fontSize: 20,
                ),
                keyboardType: TextInputType.multiline,
                maxLines: 1,
              ),
            ),
            Container(
                height: 200,
                margin: const EdgeInsets.all(10),
              child: TextField(
                controller: contentController,
                decoration: const InputDecoration(
                  labelText: '내용',
                  labelStyle: TextStyle(color: Colors.deepOrangeAccent),
                  border: OutlineInputBorder(),
                ),
                style: const TextStyle(
                  fontSize: 20,
                ),
                keyboardType: TextInputType.multiline,
                maxLines: 5,
              ),
            ),
            Container(
              height: 150,
              margin: const EdgeInsets.all(10),
              child: TextField(
                controller: rewardController,
                decoration: const InputDecoration(
                  labelText: '결과',
                  labelStyle: TextStyle(color: Colors.deepOrangeAccent),
                  //hintText: 'ex)\n인스타그램에 자동 공유',
                  border: OutlineInputBorder(),
                ),
                style: const TextStyle(
                  fontSize: 20,
                ),
                keyboardType: TextInputType.multiline,
                maxLines: 3,
              ),
            ),
            Row(mainAxisAlignment:  MainAxisAlignment.spaceEvenly,
              children: [
                TextButton(
                  child: const Text('취소',style: TextStyle(color: Colors.deepOrangeAccent),),
                  onPressed: () {
                    Get.back();
                  },
                ),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: Colors.deepOrangeAccent
                  ),
                  child: Text((index == null) ? '등록' : '수정'),
                  onPressed: () {
                    if(index == null) {
                      todoController.todos.add(Todo(title: titleController.text, content: contentController.text,  reward: rewardController.text));
                      // todoController.todos.add(Todo(content: contentController.text));
                      // todoController.todos.add(Todo(reward: rewardController.text));
                      // titleController.clear();
                      // contentController.clear();
                      // rewardController.clear();
                    } else {
                      var editing = todoController.todos[index];
                      editing.title = titleController.text;
                      editing.content = contentController.text;
                      editing.reward = rewardController.text;
                      todoController.todos[index] = editing;
                    }

                    Get.back();
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );

  }
}
