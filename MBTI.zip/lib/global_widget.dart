import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'TodoController.dart';

class GlobalWidgets {
  static final TodoController todoController = Get.find();
  static Widget button(
      {Function()? onTap,
        required Widget child,
        EdgeInsets edgeInsets = EdgeInsets.zero,
        //Color color = AppColor.transparent,
        double cornerRadius = 0}) =>
      ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Material(
          //color: color,
          child: InkWell(
            onTap: onTap,
            child: Padding(
              padding: edgeInsets,
              child: child,
            ),
          ),
        ),
      );

  static Widget checkDialog(
      {required String title,
        required String content,
        Image? image,
        String? subContent,
        Function()? onCanceled,
        Function()? onSucceed}) =>
      Dialog(
          shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Container(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 0),
              margin: const EdgeInsets.all(10),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title,
                    style: const TextStyle(
                        fontFamily: 'merriWeather',
                        color: Colors.deepOrangeAccent,
                        fontSize: 20,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 6,),
                Text(content,
                    style: const TextStyle(
                        fontFamily: 'merriWeather',
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.w500)),
                if (subContent != null) const SizedBox(height: 6),
                if (subContent != null)
                  Text(subContent,
                      style: const TextStyle(
                          fontFamily: 'merriWeather',
                          color: Colors.deepOrangeAccent,
                          fontSize: 12,
                          fontWeight: FontWeight.w400)),
                Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                  Container(
                    width: 100,
                    height: 50,
                      margin: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(width: 2, color: Colors.deepOrangeAccent)),

                      child: GlobalWidgets.button(
                          //edgeInsets: const EdgeInsets.symmetric(vertical: 10),
                          child: const Icon(
                            Icons.check,
                            color: Colors.black87,
                            size: 40,
                          ),
                          onTap: onSucceed)),
                ]),
              ])));
}
