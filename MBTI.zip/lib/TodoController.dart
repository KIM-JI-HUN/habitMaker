import 'package:get/get.dart';

import 'Todo.dart';

class TodoController extends GetxController {
  var todos = <Todo>[].obs;
}