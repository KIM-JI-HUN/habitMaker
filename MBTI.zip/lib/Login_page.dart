import 'package:flutter/material.dart';
import 'package:get/get.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({Key? key}) : super(key: key);

  static final _usernameController = TextEditingController();
  static final _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        child: Scaffold(
          body: SafeArea(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                children: <Widget>[
                  const SizedBox(height: 80.0),
                  Column(
                    children: const <Widget>[
                      Icon(Icons.view_list, size: 100,),
                      SizedBox(height: 4.0),
                      Text('MBTI별 습관 리스트',
                      style: TextStyle(
                        fontSize: 20,
                      ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 70.0),
                  TextField(
                    controller: _usernameController,
                    decoration: const InputDecoration(
                      filled: true,
                      labelText: 'ID',
                      labelStyle: TextStyle(color: Colors.deepOrangeAccent)
                    ),
                  ),
                  const SizedBox(height: 12.0),
                  TextField(
                    controller: _passwordController,
                    decoration: const InputDecoration(
                      filled: true,
                      labelText: 'Password',
                        labelStyle: TextStyle(color: Colors.deepOrangeAccent)
                    ),
                    obscureText: true,
                  ),
                  ButtonBar(
                    children: <Widget>[
                      TextButton(
                        child: const Text('취소', style: TextStyle(color: Colors.deepOrangeAccent),),
                        onPressed: () {
                          _usernameController.clear();
                          _passwordController.clear();
                        },
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          primary: Colors.deepOrangeAccent
                        ),
                        child: const Text('로그인'),
                        onPressed: () {
                          Get.toNamed('/page1');
                        },
                      ),
                    ],
                  ),
                ],
              ),
          ),
        ),
        onWillPop: () async {
          return true;
        }
    );
    throw UnimplementedError();
  }

}