
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mbti/TodoController.dart';

import '../Todo_page.dart';
import '../global_widget.dart';


class ENFJ extends StatelessWidget {
  const ENFJ({Key? key}) : super(key: key);

  static List todos = [];
  static String input = "";
  static TodoController todoController = Get.put(TodoController());
  static var now = DateTime.now().toString();
  static var date = now.substring(0, now.lastIndexOf(':'));

  @override
  Widget build(BuildContext context) {

    return WillPopScope(
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              color: Colors.deepOrangeAccent,
              onPressed: () =>
                  Get.back(),
            ),
            title: const Text('습관 리스트',
              style: TextStyle(
                  color: Colors.deepOrangeAccent,
                fontWeight: FontWeight.bold
              ),

            ),
          ),
            floatingActionButton: FloatingActionButton(
              backgroundColor: Colors.deepOrangeAccent,
              onPressed: () {
                Get.toNamed('/page3');
              },
              child: const Icon(
                Icons.add,
                color: Colors.white,
              ),
            ),
          body: Container(
            padding: const EdgeInsets.all(10),
            margin: const EdgeInsets.all(10),
            child: Obx(
                ()  => ListView.separated(
                    itemBuilder: (context, index) => ListTile(
                      shape: RoundedRectangleBorder(
                        side: const BorderSide(
                            color: Colors.grey,
                            width: 1),
                        borderRadius: BorderRadius.circular(5)
                      ),
                      title: Text(todoController.todos[index].title,
                          style: (todoController.todos[index].done)
                            ? const TextStyle(
                                      color: Colors.grey,
                                      decoration: TextDecoration.lineThrough)
                            : const TextStyle(
                                      color: Colors.black,
                                      fontSize: 18,
                          ),
                        ),
                      subtitle: Text(date),
                      onTap: () {
                        Get.to(
                          TodoPage(
                            index: index,
                          )
                        );
                      },
                      leading: Checkbox(
                        value: todoController.todos[index].done,
                        onChanged: (v) {
                          var changed = todoController.todos[index];
                          changed.done = v!;
                          todoController.todos[index] = changed;
                          Get.dialog(
                              GlobalWidgets.checkDialog(
                                  title: '성공',
                                  content: '인스타 등의 SNS에 실패 사실 공개',
                                  onSucceed: () => {
                                    Get.back(),
                                  }
                              )
                          );
                        },
                      ),
                      trailing: Checkbox(
                        activeColor: Colors.red,
                        value: todoController.todos[index].fail,
                        onChanged: (v) {
                          var changed = todoController.todos[index];
                          changed.fail = v!;
                          todoController.todos[index] = changed;
                          Get.dialog(
                              AlertDialog(
                                shape:
                                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                                title: const Text('습관 만들기 실패',
                                    style: TextStyle(
                                        color: Colors.deepOrangeAccent,
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold)),
                                content: const Text('습관 만들기에 실패하여 인스타그램에 공유되었습니다.'),
                                actions: [
                                  Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                                    Container(
                                        width: 50,
                                        height: 50,
                                        margin: const EdgeInsets.fromLTRB(0,0,0,20),

                                        child: GlobalWidgets.button(
                                          //edgeInsets: const EdgeInsets.symmetric(vertical: 10),
                                            child: const Image(image: AssetImage('assets/images/pngwing.com.png',)),
                                            onTap: () {
                                              Get.back();
                                              Get.dialog(
                                                  Image(
                                                    image: const AssetImage('assets/images/실패.png'),
                                                    height: Get.height,
                                                    width: Get.width,
                                                  )
                                              );
                                            })),
                                  ]),

                                ],
                              )
                          );
                        },
                      ),
                    ),
                    separatorBuilder: (_, __) => const Divider(),
                    itemCount: todoController.todos.length,
                )
            )
          ),
        ),
        onWillPop: () async {
          return true;
        }
    );
  }
}
