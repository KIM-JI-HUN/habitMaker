
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:mbti/TodoController.dart';

import '../Todo_page.dart';
import '../global_widget.dart';


class ISFP extends StatelessWidget {
  const ISFP({Key? key}) : super(key: key);

  static List todos = [];
  static String input = "";
  static TodoController todoController = Get.put(TodoController());
  static var now = DateTime.now().toString();
  static var date = now.substring(0, now.lastIndexOf(':'));

  @override
  Widget build(BuildContext context) {

    return WillPopScope(
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.white,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back),
              color: Colors.deepOrangeAccent,
              onPressed: () =>
                  Get.back(),
            ),
            title: const Text('습관 리스트',
              style: TextStyle(
                  color: Colors.deepOrangeAccent,
                  fontWeight: FontWeight.bold
              ),

            ),
          ),
            floatingActionButton: FloatingActionButton(
              onPressed: () {
                Get.toNamed('/page3');
              },
              child: const Icon(
                Icons.add,
                color: Colors.white,
              ),
            ),
          body: Container(
            padding: const EdgeInsets.all(10),
            margin: const EdgeInsets.all(10),
            child: Obx(
                ()  => ListView.separated(
                    itemBuilder: (context, index) => ListTile(
                      shape: RoundedRectangleBorder(
                        side: const BorderSide(
                            color: Colors.grey,
                            width: 1),
                        borderRadius: BorderRadius.circular(5)
                      ),
                      title: Text(todoController.todos[index].title,
                          style: (todoController.todos[index].done)
                            ? const TextStyle(
                                      color: Colors.grey,
                                      decoration: TextDecoration.lineThrough)
                            : const TextStyle(
                                      color: Colors.black,
                                      fontSize: 18,
                          ),
                        ),
                      subtitle: Text(date),
                      onTap: () {
                        Get.to(
                          TodoPage(
                            index: index,
                          )
                        );
                      },
                      leading: Checkbox(
                        value: todoController.todos[index].done,
                        onChanged: (v) {
                          var changed = todoController.todos[index];
                          changed.done = v!;
                          todoController.todos[index] = changed;
                          Get.dialog(
                              GlobalWidgets.checkDialog(
                                  title: '성공',
                                  content: '성공시 몇몇의 총 성공인원 안에 들었다. 실패시 몇 명의 성공자들이 있는데 들지 못했다',
                                  onSucceed: () => {
                                    Get.back(),
                                  }
                              )
                          );
                        },
                      ),
                      trailing: Checkbox(
                        activeColor: Colors.red,
                        value: todoController.todos[index].fail,
                        onChanged: (v) {
                          var changed = todoController.todos[index];
                          changed.fail = v!;
                          todoController.todos[index] = changed;
                          Get.dialog(
                              AlertDialog(
                                shape:
                                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                                title: const Text('습관 만들기 실패',
                                    style: TextStyle(
                                        color: Colors.deepOrangeAccent,
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold)),
                                content: const Image(
                                  image: AssetImage('assets/images/크라우드픽 - 저작권 걱정 없는 상업용 이미지 (2).jpg'),
                                ),
                                actions: [
                                  Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                                    Container(
                                        width: 170,
                                        height: 50,
                                        margin: const EdgeInsets.fromLTRB(0,0,0,40),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(8),
                                            border: Border.all(width: 2, color: Colors.deepOrangeAccent)),

                                        child: GlobalWidgets.button(
                                          //edgeInsets: const EdgeInsets.symmetric(vertical: 10),
                                            child: const Icon(
                                              Icons.check,
                                              color: Colors.black87,
                                              size: 40,
                                            ),
                                            onTap: () {
                                              Get.back();
                                            })),
                                  ]),

                                ],
                              )
                          );
                        },
                      ),
                    ),
                    separatorBuilder: (_, __) => const Divider(),
                    itemCount: todoController.todos.length,
                )
            )
          ),
        ),
        onWillPop: () async {
          return true;
        }
    );
  }
}
