
class Todo {
  String title;
  String content;
  String reward;
  bool done;
  bool fail;

  Todo({required this.title, required this.content, required this.reward, this.done = false, this.fail = false});

}